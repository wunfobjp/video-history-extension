const STORAGE_KEY = "video_history_sync";

// 1. 抓取集数 (适配 div.active)
function getEpisodeFromDOM() {
  try {
    const doc = window.top.document;
    // 优先寻找高亮按钮 (div 或 a)
    const activeEl = doc.querySelector('.line-res .active, .episode-item.active, .active, .current, .on');
    if (activeEl) return activeEl.innerText.trim();
    
    // 备选：URL 匹配
    const path = window.top.location.pathname;
    const allLinks = doc.querySelectorAll('.line-res div, .episode-list-box-main a');
    for (let el of allLinks) {
      if (el.innerText && (el.getAttribute('href')?.includes(path) || el.outerHTML.includes(path))) {
        return el.innerText.trim();
      }
    }
  } catch (e) {}
  return "";
}

// 2. 提取剧集 ID
function getSeriesId(url) {
  const match = url.match(/play\/(\d+)/);
  if (match) {
    const host = window.location.host.split('.');
    const name = host.length > 1 ? host[host.length - 2] : 'video';
    return `series_${name}_${match[1]}`;
  }
  return url;
}

// 3. 保存逻辑
function saveProgress(video) {
  if (!video.duration || video.duration < 5 || !chrome.runtime?.id) return;

  try {
    let topUrl, rawTitle;
    try {
      topUrl = window.top.location.href;
      rawTitle = window.top.document.title;
    } catch (e) {
      topUrl = document.referrer || window.location.href;
      rawTitle = document.title;
    }

    const seriesId = getSeriesId(topUrl);
    const epName = getEpisodeFromDOM();

    // 深度清洗标题 (去域名、去杂词)
    let cleanTitle = rawTitle
      .replace(/[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\.?/g, '')
      .replace(/(免费|在线|高清|国语|观看|蓝光|1080P|720P|中字|未删减|资源|播放|视频|樱花)/gi, '')
      .replace(/\s*(-|_|—|\|)\s*.*$/, '').trim();

    const finalTitle = epName ? `${cleanTitle} ${epName}` : cleanTitle;

    chrome.storage.sync.get(STORAGE_KEY, (res) => {
      if (chrome.runtime.lastError) return;
      let history = res[STORAGE_KEY] || {};
      history[seriesId] = {
        title: finalTitle,
        episodeUrl: topUrl,
        currentTime: Math.floor(video.currentTime),
        duration: Math.floor(video.duration),
        lastUpdated: Date.now()
      };
      // 限制 30 条
      const keys = Object.keys(history).sort((a, b) => history[b].lastUpdated - history[a].lastUpdated).slice(0, 30);
      const newHistory = {};
      keys.forEach(k => newHistory[k] = history[k]);
      chrome.storage.sync.set({ [STORAGE_KEY]: newHistory });
    });
  } catch (e) {}
}

// 4. 跳转逻辑
function seekToLast(video, time) {
  if (time > 10 && time < video.duration - 15) {
    const doSeek = () => {
      if (Math.abs(video.currentTime - time) > 5) video.currentTime = time;
      video.removeEventListener('canplay', doSeek);
    };
    video.readyState >= 1 ? doSeek() : video.addEventListener('canplay', doSeek);
  }
}

// 5. 核心监控：适配动态 Iframe
function initTracker() {
  const videos = document.querySelectorAll('video');
  videos.forEach(v => {
    if (v.dataset.isTracking) return;
    v.dataset.isTracking = "true";
    console.log("🎬 发现视频，开始记录...");

    // 初始跳转
    try {
      let url;
      try { url = window.top.location.href; } catch(e) { url = document.referrer; }
      chrome.storage.sync.get(STORAGE_KEY, (res) => {
        const history = res[STORAGE_KEY] || {};
        const record = Object.values(history).find(i => i.episodeUrl === url);
        if (record) seekToLast(v, record.currentTime);
      });
    } catch(e) {}

    v.addEventListener('pause', () => saveProgress(v));
    setInterval(() => { if (!v.paused) saveProgress(v); }, 15000);
  });
}

// 强力探测循环：每秒检查一次是否有新视频（应对异步加载）
setInterval(initTracker, 1000);
