const list = document.getElementById('history-list');
const searchInput = document.getElementById('search-input');
const STORAGE_KEY = "video_history_sync";
let allEntries = {}; // 用于存放原始对象数据

/**
 * 渲染历史列表
 * @param {Object} historyObj 存储中的历史对象
 */
function renderList(historyObj) {
  list.innerHTML = '';
  
  // 将对象转换为数组并按时间倒序排列
  const items = Object.entries(historyObj).sort((a, b) => b[1].lastUpdated - a[1].lastUpdated);

  if (items.length === 0) {
    list.innerHTML = '<li class="empty-msg">暂无观看记录</li>';
    return;
  }

  items.forEach(([key, item]) => {
    const li = document.createElement('li');
    const percent = Math.min(100, Math.round((item.currentTime / item.duration) * 100)) || 0;
    
    // 采用紧凑型 HTML 结构：标题在上，进度和续播按钮并排在下
    li.innerHTML = `
      <div class="title" title="${item.title}">${item.title}</div>
      <div class="progress-bar">
        <div class="inner" style="width:${percent}%"></div>
      </div>
      <div class="meta-row" style="display: flex; justify-content: space-between; align-items: center; margin-top: 2px;">
        <div class="meta" style="font-size: 11px; color: #888;">
          进度: ${percent}% (看到 ${Math.floor(item.currentTime / 60)}分)
        </div>
        <a href="${item.episodeUrl}" target="_blank" class="play-btn">续播</a>
      </div>
      <span class="delete-btn" data-key="${key}" title="删除此记录">×</span>
    `;
    list.appendChild(li);
  });

  // 绑定单个删除按钮点击事件
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.onclick = (e) => {
      e.preventDefault();
      const keyToDelete = e.target.getAttribute('data-key');
      if (confirm('确定删除这条记录吗？')) {
        deleteSingleRecord(keyToDelete);
      }
    };
  });
}

/**
 * 删除单个记录逻辑
 * @param {string} key 剧集的唯一标识符
 */
function deleteSingleRecord(key) {
  chrome.storage.sync.get(STORAGE_KEY, (res) => {
    let history = res[STORAGE_KEY] || {};
    delete history[key]; // 从内存对象中删除
    
    // 同步到存储
    chrome.storage.sync.set({ [STORAGE_KEY]: history }, () => {
      allEntries = history; // 更新本地副本
      renderList(history); // 重新渲染界面
    });
  });
}

/**
 * 初始化：从存储中获取数据并渲染
 */
function init() {
  chrome.storage.sync.get(STORAGE_KEY, (res) => {
    if (chrome.runtime.lastError) {
      console.error("加载历史失败:", chrome.runtime.lastError);
      return;
    }
    allEntries = res[STORAGE_KEY] || {};
    renderList(allEntries);
  });
}

/**
 * 搜索框实时过滤逻辑
 */
searchInput.addEventListener('input', (e) => {
  const keyword = e.target.value.toLowerCase().trim();
  const filtered = {};
  
  Object.keys(allEntries).forEach(key => {
    if (allEntries[key].title.toLowerCase().includes(keyword)) {
      filtered[key] = allEntries[key];
    }
  });
  
  renderList(filtered);
});

/**
 * 清空所有记录逻辑
 */
document.getElementById('clear').onclick = () => {
  if (confirm("确定要清空云端同步的所有播放记录吗？此操作不可恢复。")) {
    chrome.storage.sync.set({ [STORAGE_KEY]: {} }, () => {
      allEntries = {};
      renderList({});
    });
  }
};

// 启动程序
init();
