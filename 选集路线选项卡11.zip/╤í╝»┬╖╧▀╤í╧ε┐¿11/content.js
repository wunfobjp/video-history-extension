// content.js
const STORAGE_KEY = "video_history_data";

function isContextValid() {
    return !!chrome.runtime && !!chrome.runtime.id;
}

// 安全获取顶层文档（同源时返回父文档，否则返回当前文档）
function getTopDocumentSafe() {
    if (window === window.top) return document;
    try {
        const parentDoc = window.parent.document;
        return parentDoc;
    } catch (e) {
        return document;
    }
}

// 检测是否能访问父页面
function canAccessParent() {
    if (window === window.top) return false;
    try {
        const test = window.parent.document;
        return true;
    } catch (e) {
        return false;
    }
}

// ========== 1. 标题提取与标准化 ==========
function getPureTitle() {
    if (canAccessParent()) {
        if (typeof window.parent.getPureTitle === 'function') {
            return window.parent.getPureTitle();
        }
        const topDoc = getTopDocumentSafe();
        return getPureTitleFromDoc(topDoc);
    }
    return getPureTitleFromDoc(document);
}

function getPureTitleFromDoc(doc) {
    const hostname = window.location.hostname;

    // ----- 1.1 yuny.me -----
    if (hostname.includes('yuny.me')) {
        const titleLink = doc.querySelector('.play_detail_info a[href*="/videoDetail/"]');
        if (titleLink) {
            let raw = titleLink.getAttribute('title') || titleLink.innerText;
            if (raw) {
                let clean = raw.replace(/（.*?）/g, '').replace(/\(.*?\)/g, '')
                               .replace(/[粤国]语版$/g, '').trim();
                if (clean) {
                    const aliasMap = {
                        "正义女神": "正义女神",
                        "正义女神粤语版": "正义女神",
                        "正义女神国语版": "正义女神"
                    };
                    return aliasMap[clean] || clean;
                }
                return "正义女神";
            }
        }
        const urlParams = new URLSearchParams(window.location.search);
        const detailId = urlParams.get('detailId');
        if (detailId) return `剧集_d${detailId}`;
        const pathMatch = window.location.pathname.match(/(\d+)/);
        if (pathMatch) return `剧集_${pathMatch[1]}`;
        return fallbackTitle();
    }

    // ----- 1.2 dadaqu.me -----
    if (hostname.includes('dadaqu.me')) {
        const h1Link = doc.querySelector('.module-player-info h1 a');
        if (h1Link) {
            let raw = h1Link.getAttribute('title') || h1Link.innerText;
            if (raw) {
                let clean = raw.replace(/达达趣/gi, '')
                               .replace(/（.*?）/g, '').replace(/\(.*?\)/g, '')
                               .replace(/[粤国]语版$/g, '').trim();
                if (clean) return clean;
            }
        }
        const pageTitle = doc.title;
        if (pageTitle && !pageTitle.includes('达达趣')) {
            let clean = pageTitle.split(/[ \-|]/)[0].trim();
            if (clean && clean.length > 1) return clean;
        }
        return fallbackTitle();
    }

    // ----- 1.3 xuebiandao.com -----
    if (hostname.includes('xuebiandao.com')) {
        const breadcrumbLinks = doc.querySelectorAll('.title a');
        if (breadcrumbLinks.length > 0) {
            let lastLink = null;
            for (let i = breadcrumbLinks.length - 1; i >= 0; i--) {
                const link = breadcrumbLinks[i];
                const text = link.innerText.trim();
                if (text && text !== '首页' && !text.includes('电视剧') && !text.includes('国产剧')) {
                    lastLink = link;
                    break;
                }
            }
            if (lastLink) {
                let raw = lastLink.getAttribute('title') || lastLink.innerText;
                if (raw) return raw.trim();
            }
        }
        const pageTitle = doc.title;
        if (pageTitle && !pageTitle.includes('学变道')) {
            let clean = pageTitle.replace(/第\d+集/gi, '')
                                 .replace(/[-|]/g, '')
                                 .replace(/学变道/gi, '')
                                 .trim();
            if (clean && clean.length > 1) return clean;
        }
        const pathMatch = window.location.pathname.match(/\/(\d+)/);
        if (pathMatch && pathMatch[1]) return `剧集_${pathMatch[1]}`;
        return fallbackTitle();
    }

    // ----- 1.4 keke1.app -----
    if (hostname.includes('keke1.app')) {
        const pageTitle = doc.title;
        if (pageTitle) {
            let clean = pageTitle.replace(/第\d+集/gi, '')
                                 .replace(/[-|]/g, '')
                                 .replace(/可可影视/gi, '')
                                 .trim();
            if (clean && clean.length > 1) return clean;
        }
        return fallbackTitle();
    }

    // ----- 1.5 fofo11.com -----
    if (hostname.includes('fofo11.com')) {
        const pageTitle = doc.title;
        if (pageTitle && !pageTitle.includes('fofo')) {
            let clean = pageTitle.split(/[ \-|]/)[0].trim();
            if (clean && clean.length > 1) return clean;
        }
        const h1 = doc.querySelector('h1');
        if (h1) {
            let raw = h1.innerText.trim();
            if (raw) return raw;
        }
        return fallbackTitle();
    }

    // ----- 1.6 gimy.tv -----
    if (hostname.includes('gimy.tv') || hostname.includes('gimy.app')) {
        const titleLink = doc.querySelector('.myui-panel-box .myui-panel__head h3.title a');
        if (titleLink) {
            let raw = titleLink.innerText.trim();
            if (raw) return raw;
        }
        const pageTitle = doc.title;
        if (pageTitle) {
            let clean = pageTitle.replace(/正在观看：/, '')
                                 .replace(/第\d+集/, '')
                                 .replace(/[-|]\s*Gimy\s*剧迷/, '')
                                 .trim();
            if (clean && clean.length > 1) return clean;
        }
        return fallbackTitle();
    }

    // ----- 1.7 ifudian.com -----
    if (hostname.includes('ifudian.com')) {
        const titleH3 = doc.querySelector('.stui-pannel__head .title');
        if (titleH3) {
            let raw = titleH3.innerText.trim();
            if (raw) {
                let clean = raw.replace(/在线播放/gi, '').replace(/[ \-]/g, '').trim();
                if (clean && clean.length > 1) return clean;
            }
        }
        const pageTitle = doc.title;
        if (pageTitle && !pageTitle.includes('ifudian')) {
            let clean = pageTitle.split(/[ \-|]/)[0].trim();
            if (clean && clean.length > 1) return clean;
        }
        return fallbackTitle();
    }

    // ----- 1.8 yao-da.com -----
    if (hostname.includes('yao-da.com')) {
        const titleLink = doc.querySelector('.myui-player__data h3 a');
        if (titleLink) {
            let raw = titleLink.innerText.trim();
            if (raw) return raw;
        }
        const titleH2 = doc.querySelector('.myui-panel-box .title');
        if (titleH2) {
            let raw = titleH2.innerText.trim();
            if (raw) return raw;
        }
        try {
            const scripts = doc.querySelectorAll('script');
            for (let script of scripts) {
                const content = script.innerText;
                if (content.includes('var player_aaaa=')) {
                    const match = content.match(/vod_name":"([^"]+)"/);
                    if (match && match[1]) return match[1];
                }
            }
        } catch(e) {}
        const bodyText = doc.body.innerText;
        if (bodyText.includes('你好1983')) return '你好1983';
        if (bodyText.includes('正义女神')) return '正义女神';
        const pathMatch = window.location.pathname.match(/\/(\d+)/);
        if (pathMatch && pathMatch[1]) return `剧集_${pathMatch[1]}`;
        return fallbackTitle();
    }

    // ----- 1.9 hlyby.com (老牛影视) -----
    if (hostname.includes('hlyby.com')) {
        const pageTitle = doc.title;
        if (pageTitle) {
            let clean = pageTitle.replace(/第\d+集/gi, '')
                                 .replace(/国产剧/gi, '')
                                 .replace(/在线观看/gi, '')
                                 .replace(/免费/gi, '')
                                 .replace(/全集/gi, '')
                                 .replace(/电视剧/gi, '')
                                 .replace(/[-|]/g, '')
                                 .replace(/老牛影视/gi, '')
                                 .trim();
            if (clean && clean.length > 1) return clean;
        }
        const h1 = doc.querySelector('h1');
        if (h1) {
            let raw = h1.innerText.trim();
            if (raw) return raw;
        }
        return fallbackTitle();
    }

    // ----- 1.10 yingshiso.cc (影视搜) -----
    if (hostname.includes('yingshiso.cc')) {
        const titleLink = doc.querySelector('.stui-player__detail h1.title a');
        if (titleLink) {
            let raw = titleLink.innerText.trim();
            if (raw) return raw;
        }
        const breadcrumb = doc.querySelector('.stui-pannel-box .col-pd .text-muted:last-child');
        if (breadcrumb) {
            let raw = breadcrumb.innerText.trim().replace(/《|》/g, '');
            if (raw) return raw;
        }
        return fallbackTitle();
    }

    // ----- 1.11 beijingbaroque.com (陌陌影视) -----
    if (hostname.includes('beijingbaroque.com')) {
        const titleLink = doc.querySelector('.stui-player__detail h1.title a');
        if (titleLink) {
            let raw = titleLink.innerText.trim();
            if (raw) return raw;
        }
        try {
            const scripts = doc.querySelectorAll('script');
            for (let script of scripts) {
                const content = script.innerText;
                if (content.includes('var player_aaaa=')) {
                    const match = content.match(/vod_name":"([^"]+)"/);
                    if (match && match[1]) return match[1];
                }
            }
        } catch(e) {}
        const bodyText = doc.body.innerText;
        if (bodyText.includes('你好1983')) return '你好1983';
        if (bodyText.includes('正义女神')) return '正义女神';
        return fallbackTitle();
    }

    // ----- 1.12 ikanbot.com (爱看机器人) -----
    if (hostname.includes('ikanbot.com')) {
        const titleH1 = doc.querySelector('#video_title');
        if (titleH1) {
            let raw = titleH1.innerText.trim();
            if (raw) return raw;
        }
        const pageTitle = doc.title;
        if (pageTitle) {
            let clean = pageTitle.replace(/第\d+集/gi, '')
                                 .replace(/[-|]/g, '')
                                 .replace(/爱看机器人/gi, '')
                                 .trim();
            if (clean && clean.length > 1) return clean;
        }
        return fallbackTitle();
    }

    // ----- 1.13 zxfscl.com (三米影视) -----
    if (hostname.includes('zxfscl.com')) {
        const titleLink = doc.querySelector('.player-tips h5 a');
        if (titleLink) {
            let raw = titleLink.innerText.trim();
            if (raw) return raw;
        }
        const pageTitle = doc.title;
        if (pageTitle) {
            let clean = pageTitle.replace(/第\d+集/, '')
                                 .replace(/在线观看/, '')
                                 .replace(/三米影视/, '')
                                 .trim();
            if (clean && clean.length > 1) return clean;
        }
        return fallbackTitle();
    }

    // ----- 通用提取逻辑（增强）-----
    let raw = "";
    try {
        const metaTitle = doc.querySelector('meta[property="og:title"]');
        if (metaTitle && metaTitle.content) raw = metaTitle.content;
        if (!raw) {
            const selectors = [
                '.title a[href*="xuevod"]', '#video_title', '.detail-title strong',
                '.player-title', 'h1', '.title'
            ];
            for (let s of selectors) {
                const el = doc.querySelector(s);
                if (el && el.innerText.trim()) {
                    raw = el.innerText;
                    break;
                }
            }
        }
        if (!raw) {
            try { raw = doc.title; } catch(e) {}
        }
    } catch (e) {
        raw = "";
    }

    let clean = (raw || "").trim();

    const junk = [
        /在线播放/gi, /免费/gi, /线路/gi, /资源/gi,
        /4K/gi, /高清/gi, /1080P/gi, /720P/gi,
        /国语/gi, /粤语/gi, /英语/gi,
        /蓝光/gi, /全集/gi,
        /爱看机器人/gi, /可可影视/gi, /网飞猫/gi,
        /Moovie/gi, /影牛/gi, /达达趣/gi, /dadaqu/gi,
        /红牛资源/gi, /学变道/gi, /xuebiandao/gi,
        /Gimy/gi, /剧迷/gi, /神马影视/gi, /ifudian/gi,
        /耀达/gi, /yao-da/gi, /老牛影视/gi, /hlyby/gi,
        /国产剧/gi, /电视剧/gi, /影视搜/gi, /yingshiso/gi,
        /陌陌影视/gi, /beijingbaroque/gi,
        /播放器/gi,
        /--[^-]+--/g,
        /第\d+集/gi, /第\d+期/gi
    ];
    junk.forEach(reg => { clean = clean.replace(reg, ''); });

    clean = clean.replace(/[《》\(\)（）\[\]【】]/g, '')
                 .replace(/[（\(\[【].*?[）\)\]】]/g, '');

    let final = clean.replace(/[^\u4e00-\u9fa5a-zA-Z0-9\s]/g, '').trim();

    if (!final || final === "播放器" || final === "player" || final === "未知视频" || final.length < 2) {
        return fallbackTitle();
    }

    const aliasMap = {
        "正义女神": "正义女神",
        "你好1983": "你好1983",
        "美丽毒素第一季": "美丽毒素第一季"
    };
    if (aliasMap[final]) return aliasMap[final];

    return final;
}

// 兜底函数：返回一个基于 URL 或时间戳的唯一标识
function fallbackTitle() {
    const urlId = window.location.pathname.match(/(\d+)/);
    if (urlId) return `剧集_${urlId[1]}`;
    return `剧集_${Date.now()}`;
}

// ========== 2. 集数提取 ==========
function getEpisodeNumber() {
    if (canAccessParent()) {
        if (typeof window.parent.getEpisodeNumber === 'function') {
            return window.parent.getEpisodeNumber();
        }
        const topDoc = getTopDocumentSafe();
        return getEpisodeNumberFromDoc(topDoc);
    }
    return getEpisodeNumberFromDoc(document);
}

function getEpisodeNumberFromDoc(doc) {
    const hostname = window.location.hostname;

    // ----- 2.1 yuny.me -----
    if (hostname.includes('yuny.me')) {
        const activeEp = doc.querySelector('.detail_list_item.video_player_current_select');
        if (activeEp) {
            const epText = activeEp.innerText.trim();
            const match = epText.match(/第(\d+)集/);
            if (match) return parseInt(match[1], 10);
        }
    }

    // ----- 2.2 dadaqu.me -----
    if (hostname.includes('dadaqu.me')) {
        const activeEp = doc.querySelector('.module-play-list-link.active');
        if (activeEp) {
            const epText = activeEp.innerText.trim();
            const match = epText.match(/第(\d+)集/);
            if (match) return parseInt(match[1], 10);
        }
        const pathMatch = window.location.pathname.match(/-(\d+)\.html/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
    }

    // ----- 2.3 xuebiandao.com -----
    if (hostname.includes('xuebiandao.com')) {
        const activeLi = doc.querySelector('#vlink_4 li.playon');
        if (activeLi) {
            const a = activeLi.querySelector('a');
            if (a) {
                const epText = a.getAttribute('title') || a.innerText;
                const match = epText.match(/第(\d+)集/);
                if (match) return parseInt(match[1], 10);
            }
        }
        const pathMatch = window.location.pathname.match(/-(\d+)\.html$/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
        const bodyText = doc.body.innerText;
        const anyMatch = bodyText.match(/第(\d+)集/);
        if (anyMatch) return parseInt(anyMatch[1], 10);
    }

    // ----- 2.4 keke1.app -----
    if (hostname.includes('keke1.app')) {
        const activeEp = doc.querySelector('.episode-item-active');
        if (activeEp) {
            const epText = activeEp.innerText.trim();
            const match = epText.match(/第(\d+)集/);
            if (match) return parseInt(match[1], 10);
        }
    }

    // ----- 2.5 fofo11.com -----
    if (hostname.includes('fofo11.com')) {
        const activeEp = doc.querySelector('.playlist li.on a');
        if (activeEp) {
            const epText = activeEp.innerText.trim();
            const match = epText.match(/第(\d+)[集期]/);
            if (match) return parseInt(match[1], 10);
        }
        const pathMatch = window.location.pathname.match(/\/(\d+)(?:\.html)?$/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
    }

    // ----- 2.6 gimy.tv -----
    if (hostname.includes('gimy.tv') || hostname.includes('gimy.app')) {
        const activeEp = doc.querySelector('.myui-content__list.playlist li.active a');
        if (activeEp) {
            const epText = activeEp.innerText.trim();
            const match = epText.match(/第(\d+)[集期]/);
            if (match) return parseInt(match[1], 10);
        }
        const pathMatch = window.location.pathname.match(/-(\d+)\.html$/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
    }

    // ----- 2.7 ifudian.com -----
    if (hostname.includes('ifudian.com')) {
        const activeEp = doc.querySelector('.stui-content__playlist li.active a');
        if (activeEp) {
            const epText = activeEp.getAttribute('title') || activeEp.innerText;
            const match = epText.match(/第(\d+)[集期]/);
            if (match) return parseInt(match[1], 10);
        }
    }

    // ----- 2.8 yao-da.com -----
    if (hostname.includes('yao-da.com')) {
        const activeEp = doc.querySelector('.myui-content__list.playlist li.active a');
        if (activeEp) {
            const epText = activeEp.innerText.trim();
            const match = epText.match(/第(\d+)[集期]/);
            if (match) return parseInt(match[1], 10);
        }
        const pathMatch = window.location.pathname.match(/_(\d+)\.html$/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
        const bodyText = doc.body.innerText;
        const anyMatch = bodyText.match(/第(\d+)[集期]/);
        if (anyMatch) return parseInt(anyMatch[1], 10);
    }

    // ----- 2.9 hlyby.com -----
    if (hostname.includes('hlyby.com')) {
        const pathMatch = window.location.pathname.match(/\/(\d+)\.html$/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
        const pageTitle = doc.title;
        const match = pageTitle.match(/第(\d+)集/);
        if (match) return parseInt(match[1], 10);
    }

    // ----- 2.10 yingshiso.cc -----
    if (hostname.includes('yingshiso.cc')) {
        const activeEp = doc.querySelector('.stui-content__playlist li.playon a');
        if (activeEp) {
            const epText = activeEp.getAttribute('title') || activeEp.innerText;
            const match = epText.match(/第(\d+)[集期]/);
            if (match) return parseInt(match[1], 10);
        }
        const urlMatch = window.location.pathname.match(/-(\d+)\.html/);
        if (urlMatch && urlMatch[1]) {
            let idx = parseInt(urlMatch[1], 10);
            let ep = idx + 1;
            if (ep > 0 && ep < 1000) return ep;
        }
    }

    // ----- 2.11 beijingbaroque.com -----
    if (hostname.includes('beijingbaroque.com')) {
        const activeEp = doc.querySelector('.stui-content__playlist li.active a');
        if (activeEp) {
            const epText = activeEp.innerText.trim();
            const match = epText.match(/第(\d+)[集期]/);
            if (match) return parseInt(match[1], 10);
        }
        const pathMatch = window.location.pathname.match(/-(\d+)\.html$/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
    }

    // ----- 2.12 ikanbot.com -----
    if (hostname.includes('ikanbot.com')) {
        const activeDiv = doc.querySelector('div[name="lineData"].active');
        if (activeDiv) {
            const epText = activeDiv.innerText.trim();
            const match = epText.match(/第(\d+)[集期]/);
            if (match) return parseInt(match[1], 10);
        }
        const bodyText = doc.body.innerText;
        const anyMatch = bodyText.match(/第(\d+)[集期]/);
        if (anyMatch) return parseInt(anyMatch[1], 10);
    }

    // ----- 2.13 zxfscl.com -----
    if (hostname.includes('zxfscl.com')) {
        const activeLi = doc.querySelector('.details-play-list .active a');
        if (activeLi) {
            const epText = activeLi.innerText.trim();
            const match = epText.match(/第(\d+)集/);
            if (match) return parseInt(match[1], 10);
        }
        const pathMatch = window.location.pathname.match(/-(\d+)\.html/);
        if (pathMatch && pathMatch[1]) {
            let ep = parseInt(pathMatch[1], 10);
            if (ep > 0 && ep < 1000) return ep;
        }
    }

    // ----- 通用集数提取 -----
    try {
        const activeSelectors = [
            'li.playon', '.playon a', '.line-res .active', '.active',
            '.on', '.source-item-active', '.episode-item.active',
            '.module-play-list-link.active',
            '.episode-item-active',
            'li.on a',
            '.myui-content__list.playlist li.active a',
            '.stui-content__playlist li.active a',
            '.stui-content__playlist li.playon a',
            'div[name="lineData"].active',
            '.details-play-list .active a'
        ];
        for (let sel of activeSelectors) {
            const active = doc.querySelector(sel);
            if (active) {
                const text = active.innerText || active.getAttribute('data-episode') || '';
                const match = text.match(/第(\d+)[集期]/);
                if (match) return parseInt(match[1], 10);
            }
        }

        const path = window.location.pathname;
        const patterns = [
            /[\/\-_](\d{1,3})(?:\.html|$)/,
            /第(\d+)[集期]/,
            /ep[_-]?(\d+)/i
        ];
        for (let p of patterns) {
            const match = path.match(p);
            if (match && match[1]) {
                let ep = parseInt(match[1], 10);
                if (ep > 0 && ep < 1000) return ep;
            }
        }

        const bodyText = doc.body.innerText;
        const anyMatch = bodyText.match(/第(\d+)[集期]/);
        if (anyMatch) return parseInt(anyMatch[1], 10);
    } catch(e) {}
    return 0;
}

function getDisplayTitle() {
    const title = getPureTitle();
    const ep = getEpisodeNumber();
    return ep ? `${title} 第${ep}集` : title;
}

// ========== 新增：提取所有线路及其集数 ==========
function getEpisodeListBySource(doc) {
    const hostname = window.location.hostname;
    let sources = [];

    // ----- 针对 keke1.app 的多线路结构 -----
    if (hostname.includes('keke1.app')) {
        const sourceItems = doc.querySelectorAll('.source-list-box-main .source-item');
        const episodeContainers = doc.querySelectorAll('.episode-list-box-main .episode-list');
        if (sourceItems.length > 0 && episodeContainers.length === sourceItems.length) {
            for (let i = 0; i < sourceItems.length; i++) {
                const sourceName = sourceItems[i].querySelector('.source-item-label')?.innerText.trim() || '未知线路';
                const episodes = [];
                const links = episodeContainers[i]?.querySelectorAll('a.episode-item') || [];
                links.forEach(link => {
                    let href = link.getAttribute('href');
                    if (href) {
                        let url = href;
                        if (url.startsWith('/')) url = window.location.origin + url;
                        const text = link.innerText.trim();
                        if (text && /第\d+集/.test(text)) {
                            episodes.push({ text, url });
                        }
                    }
                });
                sources.push({ sourceName, episodes });
            }
        }
    }

    // ----- 针对 zxfscl.com 的多线路结构 -----
    if (hostname.includes('zxfscl.com')) {
        // 获取所有可能的线路集数容器（id 以 con_playlist_ 开头）
        const playlistUls = doc.querySelectorAll('ul[id^="con_playlist_"]');
        if (playlistUls.length > 0) {
            // 获取线路名称（来自 .details-play-nav > li 或下拉菜单）
            const navItems = doc.querySelectorAll('.details-play-nav > li');
            if (navItems.length === playlistUls.length) {
                for (let i = 0; i < playlistUls.length; i++) {
                    const sourceName = navItems[i].querySelector('a')?.innerText.trim() || `线路${i+1}`;
                    const episodes = [];
                    const links = playlistUls[i].querySelectorAll('a');
                    links.forEach(link => {
                        let href = link.getAttribute('href');
                        if (href) {
                            let url = href;
                            if (url.startsWith('/')) url = window.location.origin + url;
                            const text = link.innerText.trim();
                            if (text && /第\d+集/.test(text)) {
                                episodes.push({ text, url });
                            }
                        }
                    });
                    sources.push({ sourceName, episodes });
                }
            } else {
                // 如果数量不匹配，按 id 排序并生成默认名称
                const sortedUls = Array.from(playlistUls).sort((a, b) => {
                    const idA = parseInt(a.id.replace('con_playlist_', '')) || 0;
                    const idB = parseInt(b.id.replace('con_playlist_', '')) || 0;
                    return idA - idB;
                });
                sortedUls.forEach((ul, idx) => {
                    const sourceName = `线路${idx+1}`;
                    const episodes = [];
                    const links = ul.querySelectorAll('a');
                    links.forEach(link => {
                        let href = link.getAttribute('href');
                        if (href) {
                            let url = href;
                            if (url.startsWith('/')) url = window.location.origin + url;
                            const text = link.innerText.trim();
                            if (text && /第\d+集/.test(text)) {
                                episodes.push({ text, url });
                            }
                        }
                    });
                    sources.push({ sourceName, episodes });
                });
            }
        }
    }

    // 如果仍然没有，回退到原有单线路提取
    if (sources.length === 0) {
        const defaultEpisodes = getDefaultEpisodeList(doc);
        if (defaultEpisodes.length > 0) {
            sources.push({ sourceName: '默认线路', episodes: defaultEpisodes });
        }
    }

    return sources;
}

// 原有的单线路提取函数（作为 fallback）
function getDefaultEpisodeList(doc) {
    const hostname = window.location.hostname;
    let episodes = [];

    const selectors = {
        'yuny.me': '.detail_list a[href*="/videoPlayer/"]',
        'dadaqu.me': '.module-play-list-link',
        'xuebiandao.com': '#vlink_4 li a',
        'keke1.app': '.episode-list a',
        'fofo11.com': '.playlist a',
        'gimy.tv': '.myui-content__list.playlist a',
        'ifudian.com': '.stui-content__playlist a',
        'yao-da.com': '.myui-content__list.playlist a',
        'hlyby.com': '.playlist a',
        'yingshiso.cc': '.stui-content__playlist a',
        'beijingbaroque.com': '.stui-content__playlist a',
        'ikanbot.com': 'div[name="lineData"]',
        'zxfscl.com': '.details-play-list a'
    };

    for (let [domain, selector] of Object.entries(selectors)) {
        if (hostname.includes(domain)) {
            const items = doc.querySelectorAll(selector);
            items.forEach(item => {
                let href = item.getAttribute('href');
                if (href && href !== '#') {
                    let url = href;
                    if (url.startsWith('/')) url = window.location.origin + url;
                    const text = item.innerText.trim();
                    if (text && /第\d+集/.test(text)) {
                        episodes.push({ text, url });
                    }
                } else if (domain === 'ikanbot.com') {
                    const text = item.innerText.trim();
                    if (text && /第\d+集/.test(text)) {
                        episodes.push({ text, url: '#manual' });
                    }
                }
            });
            break;
        }
    }

    if (episodes.length === 0) {
        const allLinks = doc.querySelectorAll('a');
        allLinks.forEach(link => {
            const text = link.innerText.trim();
            if (text && /第\d+集/.test(text) && link.href && link.href !== '#') {
                episodes.push({ text, url: link.href });
            }
        });
    }

    const unique = [];
    const seen = new Set();
    for (let ep of episodes) {
        if (!seen.has(ep.url)) {
            seen.add(ep.url);
            unique.push(ep);
        }
    }
    return unique;
}

// ========== 3. 保存进度 ==========
function saveProgress(video) {
    if (!isContextValid() || !video || isNaN(video.duration) || video.duration < 5) return;

    const pureTitle = getPureTitle();
    if (pureTitle === "首页") return;

    const episode = getEpisodeNumber();
    const storageKey = `series_${pureTitle}`;

    let episodesBySource = [];
    try {
        episodesBySource = getEpisodeListBySource(document);
    } catch(e) {
        console.warn('getEpisodeListBySource failed', e);
    }

    const payload = {
        title: pureTitle,
        episode: episode,
        showTitle: getDisplayTitle(),
        episodeUrl: window.location.href,
        currentTime: Math.floor(video.currentTime),
        duration: Math.floor(video.duration),
        lastUpdated: Date.now(),
        episodesBySource: episodesBySource
    };

    chrome.storage.local.get(STORAGE_KEY, (res) => {
        if (chrome.runtime.lastError) {
            console.error('Storage read error:', chrome.runtime.lastError);
            return;
        }
        let history = res[STORAGE_KEY] || {};
        history[storageKey] = payload;

        const sortedKeys = Object.keys(history).sort((a, b) => history[b].lastUpdated - history[a].lastUpdated);
        const newStore = {};
        sortedKeys.slice(0, 30).forEach(k => newStore[k] = history[k]);
        chrome.storage.local.set({ [STORAGE_KEY]: newStore }, () => {
            if (chrome.runtime.lastError) {
                console.error('Storage write error:', chrome.runtime.lastError);
            } else {
                console.log('Saved progress for', pureTitle, 'episode', episode);
            }
        });
    });
}

// ========== 4. 自动恢复进度 ==========
function tryRestore(video) {
    if (!video) return;
    const pureTitle = getPureTitle();
    const storageKey = `series_${pureTitle}`;

    chrome.storage.local.get(STORAGE_KEY, (res) => {
        const record = (res[STORAGE_KEY] || {})[storageKey];
        if (record && record.currentTime > 10 && video.currentTime < 10) {
            if (video.readyState >= 1) {
                video.currentTime = record.currentTime;
            } else {
                video.addEventListener('loadedmetadata', () => {
                    video.currentTime = record.currentTime;
                }, { once: true });
            }
        }
    });
}

// ========== 5. 绑定视频元素 ==========
function attach() {
    if (!isContextValid()) return;

    document.querySelectorAll('video').forEach(v => {
        if (v.dataset.isTracked) return;
        v.dataset.isTracked = "true";

        tryRestore(v);

        v.addEventListener('pause', () => saveProgress(v));
        if (v._sync) clearInterval(v._sync);
        v._sync = setInterval(() => {
            if (isContextValid() && !v.paused) saveProgress(v);
        }, 10000);

        v.addEventListener('ended', () => saveProgress(v));
    });
}

// ========== 6. 监听 DOM 变化 ==========
const observer = new MutationObserver(() => attach());
if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
}
attach();