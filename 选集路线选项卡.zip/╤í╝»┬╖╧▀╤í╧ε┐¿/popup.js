// popup.js
const STORAGE_KEY = "video_history_data";
const listEl = document.getElementById('history-list');
const searchInput = document.getElementById('search-input');

let allItems = [];

// 简单防XSS
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

// 显示集数列表的弹窗（支持多线路选项卡）
function showEpisodeList(episodesBySource, title) {
    const modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0,0,0,0.7)';
    modal.style.zIndex = '10000';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';

    const content = document.createElement('div');
    content.style.backgroundColor = '#fff';
    content.style.borderRadius = '12px';
    content.style.width = '400px';
    content.style.maxHeight = '80%';
    content.style.display = 'flex';
    content.style.flexDirection = 'column';
    content.style.overflow = 'hidden';

    // 头部
    const header = document.createElement('div');
    header.innerHTML = `<h3 style="margin:12px 16px 0 16px; font-size:16px;">${escapeHtml(title)} - 选集</h3>`;
    content.appendChild(header);

    // 选项卡标签栏
    const tabsBar = document.createElement('div');
    tabsBar.style.display = 'flex';
    tabsBar.style.overflowX = 'auto';
    tabsBar.style.borderBottom = '1px solid #eee';
    tabsBar.style.padding = '0 12px';
    tabsBar.style.gap = '4px';
    tabsBar.style.flexShrink = '0';

    // 内容面板容器
    const panelsContainer = document.createElement('div');
    panelsContainer.style.flex = '1';
    panelsContainer.style.overflowY = 'auto';
    panelsContainer.style.padding = '12px';

    let activeIndex = 0;

    // 兼容旧数据：如果传入的是旧格式（数组对象，没有 sourceName），则转换为单线路
    let sources = [];
    if (episodesBySource && episodesBySource.length > 0 && episodesBySource[0].sourceName !== undefined) {
        sources = episodesBySource;
    } else if (episodesBySource && episodesBySource.length > 0) {
        // 旧数据，当作单线路
        sources = [{ sourceName: '默认线路', episodes: episodesBySource }];
    } else {
        sources = [];
    }

    if (sources.length === 0) {
        const noData = document.createElement('div');
        noData.textContent = '暂无集数列表';
        noData.style.padding = '20px';
        noData.style.textAlign = 'center';
        noData.style.color = '#999';
        content.appendChild(noData);
        modal.appendChild(content);
        document.body.appendChild(modal);
        return;
    }

    // 创建选项卡按钮和面板
    sources.forEach((source, idx) => {
        const tabBtn = document.createElement('button');
        tabBtn.textContent = source.sourceName;
        tabBtn.style.padding = '8px 16px';
        tabBtn.style.backgroundColor = idx === activeIndex ? '#ff4757' : '#f5f5f5';
        tabBtn.style.color = idx === activeIndex ? '#fff' : '#333';
        tabBtn.style.border = 'none';
        tabBtn.style.borderRadius = '20px 20px 0 0';
        tabBtn.style.cursor = 'pointer';
        tabBtn.style.fontSize = '13px';
        tabBtn.style.transition = 'all 0.2s';
        tabBtn.onclick = () => {
            // 切换激活样式
            for (let i = 0; i < tabsBar.children.length; i++) {
                const btn = tabsBar.children[i];
                btn.style.backgroundColor = i === idx ? '#ff4757' : '#f5f5f5';
                btn.style.color = i === idx ? '#fff' : '#333';
            }
            // 切换面板可见性
            for (let i = 0; i < panelsContainer.children.length; i++) {
                panelsContainer.children[i].style.display = i === idx ? 'block' : 'none';
            }
        };
        tabsBar.appendChild(tabBtn);

        // 创建面板（单列垂直列表）
        const panel = document.createElement('div');
        panel.style.display = idx === activeIndex ? 'block' : 'none';

        const episodes = source.episodes;
        if (episodes && episodes.length > 0) {
            episodes.forEach(ep => {
                const btn = document.createElement('button');
                btn.textContent = ep.text;
                btn.style.display = 'block';
                btn.style.width = '100%';
                btn.style.padding = '8px';
                btn.style.margin = '5px 0';
                btn.style.backgroundColor = '#f5f5f5';
                btn.style.border = '1px solid #e0e0e0';
                btn.style.borderRadius = '6px';
                btn.style.fontSize = '13px';
                btn.style.cursor = 'pointer';
                btn.style.textAlign = 'left';
                btn.style.transition = 'all 0.2s';
                btn.onmouseover = () => { btn.style.backgroundColor = '#ff4757'; btn.style.color = '#fff'; };
                btn.onmouseout = () => { btn.style.backgroundColor = '#f5f5f5'; btn.style.color = '#333'; };
                btn.onclick = () => {
                    if (ep.url === '#manual') {
                        alert(`该网站无直接集数链接，请手动切换到“${ep.text}”。`);
                    } else {
                        window.open(ep.url, '_blank');
                    }
                    modal.remove();
                };
                panel.appendChild(btn);
            });
        } else {
            const msg = document.createElement('div');
            msg.textContent = '暂无集数';
            msg.style.padding = '20px';
            msg.style.textAlign = 'center';
            msg.style.color = '#999';
            panel.appendChild(msg);
        }
        panelsContainer.appendChild(panel);
    });

    // 关闭按钮
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '关闭';
    closeBtn.style.margin = '12px 16px 16px auto';
    closeBtn.style.padding = '6px 16px';
    closeBtn.style.backgroundColor = '#ff4757';
    closeBtn.style.color = '#fff';
    closeBtn.style.border = 'none';
    closeBtn.style.borderRadius = '20px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.style.fontSize = '12px';
    closeBtn.onclick = () => modal.remove();

    content.appendChild(tabsBar);
    content.appendChild(panelsContainer);
    content.appendChild(closeBtn);
    modal.appendChild(content);
    document.body.appendChild(modal);
}

// 辅助函数：尝试在 URL 中替换集数数字（用于手动输入）
function replaceEpisodeNumber(url, targetEp) {
    const parts = url.split('/');
    for (let i = parts.length - 1; i >= 0; i--) {
        const part = parts[i];
        const match = part.match(/(\d+)/);
        if (match) {
            const newPart = part.replace(match[1], targetEp);
            parts[i] = newPart;
            return parts.join('/');
        }
    }
    return null;
}

function render(items) {
    if (items.length === 0) {
        listEl.innerHTML = '<li class="empty-msg">暂无观看记录</li>';
        return;
    }

    listEl.innerHTML = items.map(item => {
        const percent = Math.round((item.currentTime / item.duration) * 100) || 0;
        const storageId = `series_${item.title}`;
        const episodesBySourceJson = JSON.stringify(item.episodesBySource || []).replace(/</g, '\\u003c');

        return `
            <li>
                <div class="info">
                    <div class="title" title="${escapeHtml(item.showTitle)}">${escapeHtml(item.showTitle)}</div>
                    <div class="progress-container">
                        <div class="progress-bar"><div class="inner" style="width:${percent}%"></div></div>
                        <span class="percent-tag">${percent}%</span>
                    </div>
                    <div class="meta">进度: ${Math.floor(item.currentTime/60)}分 / 全长:${Math.floor(item.duration/60)}分</div>
                </div>
                <div class="actions">
                    <a href="${item.episodeUrl}" target="_blank" class="play-btn">续播</a>
                    <button class="episode-btn" data-title="${escapeHtml(item.title)}" data-episodes='${episodesBySourceJson}' data-last-url="${item.episodeUrl}">选集</button>
                    <span class="del-btn" data-id="${storageId}">删除</span>
                </div>
            </li>
        `;
    }).join('');

    // 绑定删除按钮
    document.querySelectorAll('.del-btn').forEach(btn => {
        btn.onclick = (e) => {
            const id = e.target.dataset.id;
            chrome.storage.local.get(STORAGE_KEY, (res) => {
                let d = res[STORAGE_KEY] || {};
                delete d[id];
                chrome.storage.local.set({ [STORAGE_KEY]: d }, () => loadAndRender());
            });
        };
    });

    // 绑定选集按钮
    document.querySelectorAll('.episode-btn').forEach(btn => {
        btn.onclick = (e) => {
            const title = btn.dataset.title;
            let episodesBySource = [];
            try {
                episodesBySource = JSON.parse(btn.dataset.episodes);
            } catch(e) {}
            const lastUrl = btn.dataset.lastUrl;

            if (episodesBySource && episodesBySource.length > 0) {
                showEpisodeList(episodesBySource, title);
            } else {
                // 降级到手动输入
                let epNum = prompt(`请输入要跳转的集数（数字）`, "1");
                if (epNum && !isNaN(parseInt(epNum))) {
                    const newUrl = replaceEpisodeNumber(lastUrl, parseInt(epNum));
                    if (newUrl) {
                        window.open(newUrl, '_blank');
                    } else {
                        alert("无法自动构造该集数的链接，请手动打开网页。");
                    }
                }
            }
        };
    });
}

function loadAndRender() {
    chrome.storage.local.get(STORAGE_KEY, (res) => {
        if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError);
            listEl.innerHTML = '<li class="empty-msg">读取数据失败</li>';
            return;
        }
        const data = res[STORAGE_KEY] || {};
        allItems = Object.values(data).sort((a, b) => (b.lastUpdated || 0) - (a.lastUpdated || 0));
        applyFilter();
    });
}

function applyFilter() {
    const keyword = searchInput.value.trim().toLowerCase();
    if (!keyword) {
        render(allItems);
        return;
    }
    const filtered = allItems.filter(item => {
        const title = (item.showTitle || item.title || '').toLowerCase();
        return title.includes(keyword);
    });
    render(filtered);
}

// 清空全部
document.getElementById('clear').onclick = () => {
    if (confirm("清空全部记录？")) {
        chrome.storage.local.set({ [STORAGE_KEY]: {} }, () => loadAndRender());
    }
};

// 搜索防抖
let debounceTimer;
searchInput.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(applyFilter, 300);
});

document.addEventListener('DOMContentLoaded', loadAndRender);