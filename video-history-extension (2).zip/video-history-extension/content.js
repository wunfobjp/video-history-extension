const STORAGE_KEY = "video_history_sync";

// 1. 核心：提取剧集唯一 ID（修复了 match 取值问题）
function getSeriesId(url) {
  // 匹配常见的 /play/12345 模式
  const match = url.match(/play\/(\d+)/);
  if (match && match[1]) {
    // 提取域名中间部分，如 ikanbot / waijumi
    const hostParts = window.location.host.split('.');
    const host = hostParts.length > 2 ? hostParts[1] : hostParts[0];
    return `series_${host}_${match[1]}`; 
  }
  return url; 
}

// 2. 核心：保存逻辑
function saveProgress(video) {
  // 过滤广告或太短的视频
  if (!video.duration || video.duration < 10) return;

  try {
    const topUrl = window.top.location.href;
    const seriesId = getSeriesId(topUrl);
    
    // 获取标题并深度清洗
    let rawTitle = "";
    try {
        rawTitle = window.top.document.title || document.title;
    } catch(e) {
        rawTitle = document.title;
    }

    let cleanTitle = rawTitle
      .replace(/第\s*\d+\s*[集期].*$/, '') // 移除 第x集
      .replace(/(\s*-\s*)(外剧迷|爱看机器人|在线播放|全集|高清).*$/, '') // 移除网站后缀
      .trim();

    const payload = {
      title: cleanTitle || "未知影片",
      episodeUrl: topUrl,
      currentTime: Math.floor(video.currentTime),
      duration: Math.floor(video.duration),
      lastUpdated: Date.now()
    };

    chrome.storage.sync.get(STORAGE_KEY, (res) => {
      let history = res[STORAGE_KEY] || {};
      
      // 同剧集覆盖逻辑
      history[seriesId] = payload;

      // 限制 30 条记录，防止存储溢出
      const sortedKeys = Object.keys(history).sort((a, b) => history[b].lastUpdated - history[a].lastUpdated);
      const newHistory = {};
      sortedKeys.slice(0, 30).forEach(k => newHistory[k] = history[k]);

      chrome.storage.sync.set({ [STORAGE_KEY]: newHistory });
    });
  } catch (e) {
    console.error("保存进度失败:", e);
  }
}

// 3. 视频对象监听
function attachTracker() {
  const videos = document.querySelectorAll('video');
  videos.forEach(v => {
    if (v.dataset.isTracking) return;
    v.dataset.isTracking = "true";

    // 监听暂停
    v.addEventListener('pause', () => saveProgress(v));
    
    // 监听播放结束
    v.addEventListener('ended', () => saveProgress(v));

    // 每 10 秒自动保存一次
    setInterval(() => {
      if (!v.paused) saveProgress(v);
    }, 10000);

    console.log("🎬 进度助手：已锁定视频播放器");
  });
}

// 4. 安全启动（解决 MutationObserver 报错）
function startApp() {
  const targetNode = document.body || document.documentElement;
  if (targetNode) {
    const observer = new MutationObserver(() => attachTracker());
    observer.observe(targetNode, { childList: true, subtree: true });
    attachTracker();
  } else {
    setTimeout(startApp, 250); 
  }
}

// 启动执行
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApp);
} else {
    startApp();
}
