const list = document.getElementById('history-list');
const searchInput = document.getElementById('search-input');
const STORAGE_KEY = "video_history_sync";
let allHistory = []; // 用于存放原始数据

// 渲染函数
function renderList(items) {
  list.innerHTML = '';
  if (items.length === 0) {
    list.innerHTML = '<li class="empty-msg">未找到相关记录</li>';
    return;
  }

  items.forEach(item => {
    const li = document.createElement('li');
    const percent = Math.round((item.currentTime / item.duration) * 100) || 0;
    li.innerHTML = `
      <div class="info">
        <div class="title" title="${item.title}">${item.title}</div>
        <div class="progress-bar"><div class="inner" style="width:${percent}%"></div></div>
        <div class="meta">进度: ${percent}% (看到 ${Math.floor(item.currentTime/60)}分)</div>
      </div>
      <a href="${item.episodeUrl}" target="_blank" class="play-btn">续播</a>
    `;
    list.appendChild(li);
  });
}

// 初始化加载
chrome.storage.sync.get(STORAGE_KEY, (res) => {
  const history = res[STORAGE_KEY] || {};
  // 转换为数组并按时间排序
  allHistory = Object.values(history).sort((a, b) => b.lastUpdated - a.lastUpdated);
  renderList(allHistory);
});

// 监听搜索输入
searchInput.addEventListener('input', (e) => {
  const keyword = e.target.value.toLowerCase();
  const filtered = allHistory.filter(item => 
    item.title.toLowerCase().includes(keyword)
  );
  renderList(filtered);
});

// 清空逻辑
document.getElementById('clear').onclick = () => {
  if(confirm("确定清空所有云同步记录？")) {
    chrome.storage.sync.set({ [STORAGE_KEY]: {} }, () => location.reload());
  }
};
