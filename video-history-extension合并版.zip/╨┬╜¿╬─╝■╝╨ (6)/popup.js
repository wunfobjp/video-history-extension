const STORAGE_KEY = "video_history_data";
const list = document.getElementById('history-list');

function render() {
    chrome.storage.local.get(STORAGE_KEY, (res) => {
        const data = res[STORAGE_KEY] || {};
        const items = Object.values(data).sort((a, b) => b.lastUpdated - a.lastUpdated);
        
        if (items.length === 0) {
            list.innerHTML = '<li class="empty-msg">暂无观看记录</li>';
            return;
        }

        list.innerHTML = items.map(item => {
            const percent = Math.round((item.currentTime / item.duration) * 100) || 0;
            // 重要：这里的 data-id 逻辑必须与 content.js 的 series_ 保持一致
            const sId = `series_${item.title}`;
            return `
                <li>
                    <div class="info">
                        <div class="title" title="${item.showTitle}">${item.showTitle}</div>
                        <div class="progress-container">
                            <div class="progress-bar"><div class="inner" style="width:${percent}%"></div></div>
                            <span class="percent-tag">${percent}%</span>
                        </div>
                        <div class="meta">进度: ${Math.floor(item.currentTime/60)}分 / 全长:${Math.floor(item.duration/60)}分</div>
                    </div>
                    <div class="actions">
                        <a href="${item.episodeUrl}" target="_blank" class="play-btn">续播</a>
                        <span class="del-btn" data-id="${sId}">删除</span>
                    </div>
                </li>
            `;
        }).join('');

        // 重新绑定删除逻辑
        document.querySelectorAll('.del-btn').forEach(btn => {
            btn.onclick = (e) => {
                const id = e.target.dataset.id;
                chrome.storage.local.get(STORAGE_KEY, (res) => {
                    let d = res[STORAGE_KEY] || {};
                    delete d[id];
                    chrome.storage.local.set({ [STORAGE_KEY]: d }, render);
                });
            };
        });
    });
}
document.getElementById('clear').onclick = () => {
    if(confirm("清空全部？")) chrome.storage.local.set({ [STORAGE_KEY]: {} }, render);
};
document.addEventListener('DOMContentLoaded', render);
