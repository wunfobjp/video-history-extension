const STORAGE_KEY = "video_history_data";

function isContextValid() { return !!chrome.runtime && !!chrome.runtime.id; }

// --- 1. 标题提取 (增加“在线播放”剔除) ---
function getPureTitle() {
    let raw = "";
    try {
        const selectors = ['.title a[href*="xuevod"]', '#video_title', '.detail-title strong', '.player-title', 'h1', '.title'];
        for (let s of selectors) {
            const el = document.querySelector(s);
            if (el && el.innerText.trim()) { raw = el.innerText; break; }
        }
        if (!raw) {
            try { raw = window.top.document.title; } catch(e) { raw = document.title; }
        }
    } catch (e) { raw = ""; }

    let clean = (raw || "").trim();
    
    // A. 强制剔除“在线播放”字样 (解决截图第一个条目的问题)
    clean = clean.replace(/在线播放/g, '');
    
    // B. 分段切割，只留第一段
    if (clean.includes("第")) { clean = clean.split(/第\s*\d+\s*[集期]/)[0]; }

    // C. 关键词黑名单
    const junk = [/--爱看机器人.*/i, /-ikanbot.*/i, /-可可.*/i, /-学变道.*/i, /-Moovie.*/i, /-一星车.*/i, /粤语/g, /国语/g, /蓝光/g, /高清/g, /1080P/gi];
    junk.forEach(reg => { clean = clean.replace(reg, ''); });

    // D. 彻底剔除符号
    clean = clean.replace(/[《》\(\)（）\[\]【】]/g, '').replace(/[（\(\[【].*?[）\)\]】]/g, '');

    // E. 终极去燥：只留中英数
    let final = clean.replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, '').trim();

    // 兜底：如果名字洗成了 player 或为空，用 URL ID
    if (!final || final === "player" || final === "未知视频") {
        const urlId = window.location.pathname.match(/(\d+)/);
        return urlId ? `剧集_${urlId[1]}` : "未识别视频";
    }
    return final;
}

// --- 2. 精准集数提取 (增加长度限制，防止误抓 ID) ---
function getActiveEpisode() {
    try {
        // 策略 A: 找页面高亮按钮 (最准)
        const active = document.querySelector('li.playon, .playon a, .line-res .active, .active, .on, .source-item-active');
        if (active) {
            const m = (active.innerText || "").match(/第\d+[集期]/);
            if (m) return `[${m[0]}] `;
        }

        // 策略 B: URL 解析 (针对 329640-19-623156.html 这种结构)
        const path = window.location.pathname;
        const parts = path.split(/[-_]/).map(p => p.replace('.html', ''));
        // 过滤出纯数字且长度小于 4 的部分 (集数一般不会超过 999)
        const possibleEps = parts.filter(p => !isNaN(p) && p.length > 0 && p.length < 4);
        if (possibleEps.length > 0) {
            // 取最后符合条件的一个数字 (通常 19 就是集数)
            return `[第${parseInt(possibleEps[possibleEps.length - 1])}集] `;
        }
    } catch (e) {}
    return "";
}

// --- 3. 保存逻辑 ---
function saveProgress(video) {
    if (!isContextValid() || !video || isNaN(video.duration) || video.duration < 5) return;
    
    const pureTitle = getPureTitle();
    // 拦截无效标题
    if (pureTitle === "未识别视频" || pureTitle === "首页") return;

    const episodeStr = getActiveEpisode();
    const payload = {
        title: pureTitle,
        showTitle: episodeStr + pureTitle,
        episodeUrl: window.location.href,
        currentTime: Math.floor(video.currentTime),
        duration: Math.floor(video.duration),
        lastUpdated: Date.now()
    };

    chrome.storage.local.get(STORAGE_KEY, (res) => {
        if (chrome.runtime.lastError) return;
        let history = res[STORAGE_KEY] || {};
        // 只要 pureTitle 相同，就会写入同一个 Key 从而实现合并
        history[`series_${pureTitle}`] = payload;
        
        const sortedKeys = Object.keys(history).sort((a, b) => history[b].lastUpdated - history[a].lastUpdated);
        const newStore = {};
        sortedKeys.slice(0, 30).forEach(k => newStore[k] = history[k]);
        chrome.storage.local.set({ [STORAGE_KEY]: newStore });
    });
}

function attach() {
    if (!isContextValid()) return;
    document.querySelectorAll('video').forEach(v => {
        if (v.dataset.isTracked) return;
        v.dataset.isTracked = "true";
        
        // 自动跳转
        chrome.storage.local.get(STORAGE_KEY, (res) => {
            const record = (res[STORAGE_KEY] || {})[`series_${getPureTitle()}`];
            if (record && record.currentTime > 10 && v.currentTime < 10) v.currentTime = record.currentTime;
        });

        v.addEventListener('pause', () => saveProgress(v));
        if (v._sync) clearInterval(v._sync);
        v._sync = setInterval(() => {
            if (isContextValid() && !v.paused) saveProgress(v);
        }, 10000);
    });
}

const observer = new MutationObserver(attach);
if (document.body) observer.observe(document.body, { childList: true, subtree: true });
attach();
